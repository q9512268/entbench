#ifndef _CLASSPATH_INCLUDE_CONFIG_INT_H
#define _CLASSPATH_INCLUDE_CONFIG_INT_H 1
#ifndef _GENERATED_STDINT_H
#define _GENERATED_STDINT_H "classpath 0.99"
/* generated using gnu compiler gcc (Gentoo 4.6.2) 4.6.2 */
#define _STDINT_HAVE_STDINT_H 1
#include <stdint.h>
#endif
#endif
